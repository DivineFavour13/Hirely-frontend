import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Plus, Users } from "lucide-react";
import { getApplicants } from "@/api/applicants";
import { PageHeader } from "@/components/shared/PageHeader";
import { CreateApplicantDialog } from "./CreateApplicantDialog";
import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";

export function ApplicantsPage() {
  const [dialogOpen, setDialogOpen] = useState(false);

  const { data: applicants, isLoading, isError, refetch } = useQuery({
    queryKey: ["applicants"],
    queryFn: getApplicants,
  });

  return (
    <div className="px-8 py-8">
      <PageHeader
        title="Applicants"
        subtitle="Everyone who's applied through Hirely."
        action={
          <button
            onClick={() => setDialogOpen(true)}
            className="flex items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-[13.5px] font-medium text-white hover:bg-slate-800"
          >
            <Plus className="h-4 w-4" />
            Add applicant
          </button>
        }
      />

      {isLoading && <LoadingState label="Loading applicants…" />}
      {isError && <ErrorState message="Couldn't load applicants." onRetry={() => refetch()} />}

      {applicants && applicants.length === 0 && (
        <div className="rounded-xl border border-dashed border-slate-200 py-16 text-center">
          <Users className="mx-auto h-8 w-8 text-slate-300" />
          <p className="mt-3 text-sm text-slate-500">No applicants yet.</p>
        </div>
      )}

      {applicants && applicants.length > 0 && (
        <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
          <table className="w-full text-left">
            <thead className="border-b border-slate-100 bg-slate-50/50">
              <tr>
                {["Name", "Email", "Phone", "Skills"].map((h) => (
                  <th key={h} className="px-5 py-3 text-[12px] font-medium uppercase tracking-wide text-slate-500">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {applicants.map((applicant) => (
                <tr key={applicant.id} className="hover:bg-slate-50/50">
                  <td className="px-5 py-3.5 text-[13.5px] font-medium text-slate-900">
                    {applicant.name}
                  </td>
                  <td className="px-5 py-3.5 text-[13.5px] text-slate-600">{applicant.email}</td>
                  <td className="px-5 py-3.5 text-[13.5px] text-slate-600">
                    {applicant.phone || "—"}
                  </td>
                  <td className="px-5 py-3.5 text-[13.5px] text-slate-600">
                    <span className="line-clamp-1">{applicant.skills || "—"}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <CreateApplicantDialog open={dialogOpen} onClose={() => setDialogOpen(false)} />
    </div>
  );
}