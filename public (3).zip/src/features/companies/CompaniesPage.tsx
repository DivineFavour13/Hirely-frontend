import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Plus, Building2 } from "lucide-react";
import { getCompanies } from "@/api/companies";
import { PageHeader } from "@/components/shared/PageHeader";
import { CreateCompanyDialog } from "./CreateCompanyDialog";
import { useAuth } from "@/context/AuthContext";
import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";

export function CompaniesPage() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const { user } = useAuth();
  const canCreate = user?.role === "ADMIN";

  const { data: companies, isLoading, isError, refetch } = useQuery({
    queryKey: ["companies"],
    queryFn: getCompanies,
  });

  return (
    <div className="px-8 py-8">
      <PageHeader
        title="Companies"
        subtitle="Organizations posting roles on Hirely."
        action={
          canCreate && (
            <button
              onClick={() => setDialogOpen(true)}
              className="flex items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-[13.5px] font-medium text-white hover:bg-slate-800"
            >
              <Plus className="h-4 w-4" />
              Add company
            </button>
          )
        }
      />

      {isLoading && <LoadingState label="Loading companies…" />}
      {isError && <ErrorState message="Couldn't load companies." onRetry={() => refetch()} />}

      {companies && companies.length === 0 && (
        <div className="rounded-xl border border-dashed border-slate-200 py-16 text-center">
          <Building2 className="mx-auto h-8 w-8 text-slate-300" />
          <p className="mt-3 text-sm text-slate-500">No companies yet.</p>
        </div>
      )}

      {companies && companies.length > 0 && (
        <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
          <table className="w-full text-left">
            <thead className="border-b border-slate-100 bg-slate-50/50">
              <tr>
                {["Name", "Industry", "Location", "Website"].map((h) => (
                  <th
                    key={h}
                    className="px-5 py-3 text-[12px] font-medium uppercase tracking-wide text-slate-500"
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {companies.map((company) => (
                <tr key={company.id} className="hover:bg-slate-50/50">
                  <td className="px-5 py-3.5 text-[13.5px] font-medium text-slate-900">
                    {company.name}
                  </td>
                  <td className="px-5 py-3.5 text-[13.5px] text-slate-600">
                    {company.industry || "—"}
                  </td>
                  <td className="px-5 py-3.5 text-[13.5px] text-slate-600">
                    {company.location || "—"}
                  </td>
                  <td className="px-5 py-3.5 text-[13.5px] text-indigo-600">
                    {company.website ? (
                      <a href={company.website} target="_blank" rel="noreferrer" className="hover:underline">
                        {company.website.replace(/^https?:\/\//, "")}
                      </a>
                    ) : (
                      <span className="text-slate-400">—</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <CreateCompanyDialog open={dialogOpen} onClose={() => setDialogOpen(false)} />
    </div>
  );
}