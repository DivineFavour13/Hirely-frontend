import { PageHeader } from "@/components/shared/PageHeader";
import { KanbanBoard } from "./KanbanBoard";

export function TrackingPage() {
  return (
    <div className="px-8 py-8">
      <PageHeader title="Tracking" subtitle="Drag a candidate to move them through the pipeline." />
      <KanbanBoard />
    </div>
  );
}