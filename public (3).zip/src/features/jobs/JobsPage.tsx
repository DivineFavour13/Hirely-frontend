import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Plus, Briefcase, Search } from "lucide-react";
import { searchJobs } from "@/api/jobs";
import type { EmploymentType, JobStatus } from "@/types/job";
import { PageHeader } from "@/components/shared/PageHeader";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { CreateJobDialog } from "./CreateJobDialog";
import { ApplyDialog } from "./ApplyDialog";
import { EditJobDialog } from "./EditJobDialog";
import { useAuth } from "@/context/AuthContext";
import { LoadingState } from "@/components/shared/LoadingState";
import { ErrorState } from "@/components/shared/ErrorState";
import type { Job } from "@/types/job";

const employmentTypes: EmploymentType[] = ["FULL_TIME", "PART_TIME", "CONTRACT", "INTERNSHIP"];

export function JobsPage() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [applyJob, setApplyJob] = useState<Job | null>(null);
  const [editJob, setEditJob] = useState<Job | null>(null);
  const [keyword, setKeyword] = useState("");
  const [employmentType, setEmploymentType] = useState<EmploymentType | "">("");
  const [location, setLocation] = useState("");
  const [page, setPage] = useState(0);

  const { user } = useAuth();
  const canCreate = user?.role === "ADMIN" || user?.role === "COMPANY_REP";
  const canApply = user?.role === "APPLICANT";

  const { data, isLoading, isError, refetch } = useQuery({
    queryKey: ["jobs", "search", { keyword, employmentType, location, page }],
    queryFn: () =>
      searchJobs({
        keyword: keyword || undefined,
        employmentType: employmentType || undefined,
        location: location || undefined,
        page,
        size: 10,
      }),
  });

  function formatSalary(job: { minSalary?: number; maxSalary?: number }) {
    if (!job.minSalary && !job.maxSalary) return "—";
    return `$${job.minSalary?.toLocaleString() ?? "?"} – $${job.maxSalary?.toLocaleString() ?? "?"}`;
  }

  const jobs = data?.content ?? [];
  const inputClass =
    "rounded-lg border border-slate-200 bg-white px-3 py-2 text-[13.5px] text-slate-900 placeholder:text-slate-400 focus:border-indigo-400 focus:outline-none focus:ring-4 focus:ring-indigo-500/10";

  return (
    <div className="px-8 py-8">
      <PageHeader
        title="Jobs"
        subtitle="Open and past roles across every company."
        action={
          canCreate && (
            <button
              onClick={() => setDialogOpen(true)}
              className="flex items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-[13.5px] font-medium text-white hover:bg-slate-800"
            >
              <Plus className="h-4 w-4" />
              Post job
            </button>
          )
        }
      />

      <div className="mb-5 flex flex-wrap gap-2">
        <div className="relative">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
          <input
            value={keyword}
            onChange={(e) => {
              setKeyword(e.target.value);
              setPage(0);
            }}
            placeholder="Search title or description…"
            className={`${inputClass} w-56 pl-8`}
          />
        </div>

        <select
          value={employmentType}
          onChange={(e) => {
            setEmploymentType(e.target.value as EmploymentType | "");
            setPage(0);
          }}
          className={inputClass}
        >
          <option value="">All types</option>
          {employmentTypes.map((t) => (
            <option key={t} value={t}>{t.replace("_", " ")}</option>
          ))}
        </select>

        <input
          value={location}
          onChange={(e) => {
            setLocation(e.target.value);
            setPage(0);
          }}
          placeholder="Location"
          className={`${inputClass} w-40`}
        />
      </div>

      {isLoading && <LoadingState label="Loading jobs…" />}
      {isError && <ErrorState message="Couldn't load jobs." onRetry={() => refetch()} />}

      {data && jobs.length === 0 && (
        <div className="rounded-xl border border-dashed border-slate-200 py-16 text-center">
          <Briefcase className="mx-auto h-8 w-8 text-slate-300" />
          <p className="mt-3 text-sm text-slate-500">No jobs match your filters.</p>
        </div>
      )}

      {data && jobs.length > 0 && (
        <>
          <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
            <table className="w-full text-left">
              <thead className="border-b border-slate-100 bg-slate-50/50">
                <tr>
                  {["Title", "Company", "Type", "Salary", "Status", ""].map((h) => (
                    <th key={h} className="px-5 py-3 text-[12px] font-medium uppercase tracking-wide text-slate-500">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {jobs.map((job) => (
                  <tr key={job.id} className="hover:bg-slate-50/50">
                    <td className="px-5 py-3.5 text-[13.5px] font-medium text-slate-900">{job.title}</td>
                    <td className="px-5 py-3.5 text-[13.5px] text-slate-600">{job.company.name}</td>
                    <td className="px-5 py-3.5 text-[13.5px] text-slate-600">
                      {job.employmentType?.replace("_", " ") ?? "—"}
                    </td>
                    <td className="px-5 py-3.5 text-[13.5px] text-slate-600">{formatSalary(job)}</td>
                    <td className="px-5 py-3.5">
                      <StatusBadge status={job.status} />
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      <div className="flex justify-end gap-2">
                        {canCreate && (
                          <button
                            onClick={() => setEditJob(job)}
                            className="rounded-lg border border-slate-200 px-3 py-1.5 text-[12.5px] font-medium text-slate-700 hover:bg-slate-50"
                          >
                            Edit
                          </button>
                        )}
                        {canApply && (
                          <button
                            onClick={() => setApplyJob(job)}
                            className="rounded-lg border border-slate-200 px-3 py-1.5 text-[12.5px] font-medium text-slate-700 hover:bg-slate-50"
                          >
                            Apply
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="mt-4 flex items-center justify-between text-[13px] text-slate-500">
            <span>
              Page {data.number + 1} of {data.totalPages} · {data.totalElements} total
            </span>
            <div className="flex gap-2">
              <button
                onClick={() => setPage((p) => Math.max(0, p - 1))}
                disabled={data.number === 0}
                className="rounded-lg border border-slate-200 px-3 py-1.5 font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-40"
              >
                Previous
              </button>
              <button
                onClick={() => setPage((p) => p + 1)}
                disabled={data.number + 1 >= data.totalPages}
                className="rounded-lg border border-slate-200 px-3 py-1.5 font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-40"
              >
                Next
              </button>
            </div>
          </div>
        </>
      )}

      <CreateJobDialog open={dialogOpen} onClose={() => setDialogOpen(false)} />
      <ApplyDialog job={applyJob} onClose={() => setApplyJob(null)} />
      <EditJobDialog job={editJob} onClose={() => setEditJob(null)} />
    </div>
  );
}